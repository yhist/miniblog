<template>
  <header class="header">
    <h1>Header</h1>
  </header>
</template>

<script>
export default {

}
</script>

<style scoped>
  h1 {
    text-align: center;
    font-weight: 700;
  }
</style>